console.log("Copy Paste Helper loaded");
/*
 * Check whether the keyboard event is a clipboard shortcut
 */
function isClipboardShortcut(event) {
  const key = event.key.toLowerCase();

  return (
    ((event.ctrlKey || event.metaKey) && ["c", "v", "x"].includes(key)) ||
    (event.shiftKey && key === "insert")
  );
}

/*
 * Check whether beforeinput is related to paste
 */
function isPasteInput(event) {
  const pasteTypes = [
    "insertFromPaste",
    "insertFromDrop",
    "insertReplacementText",
  ];

  return pasteTypes.includes(event.inputType);
}

/*
 * 1. KEYBOARD SHORTCUTS
 *
 * Allow:
 * Ctrl + C
 * Ctrl + V
 * Ctrl + X
 * Cmd + C/V/X
 * Shift + Insert
 *
 * We do NOT call preventDefault().
 * We only stop the website's JavaScript
 * from seeing the keyboard event.
 */
window.addEventListener(
  "keydown",
  (event) => {
    const key = event.key.toLowerCase();

    const isDevToolsShortcut =
      key === "f12" ||
      (event.ctrlKey && event.shiftKey && ["i", "j", "c"].includes(key));

    const isClipboard = isClipboardShortcut(event);

    /*
     * Handle clipboard shortcuts
     */
    if (isClipboard) {
      console.log("Allowing clipboard shortcut:", event.key);

      event.stopImmediatePropagation();

      return;
    }

    /*
     * Keep the old DevTools shortcut behaviour
     */
    if (isDevToolsShortcut) {
      console.log("Allowing shortcut:", event.key);

      event.stopImmediatePropagation();
    }
  },
  true,
);

/*
 * 2. COPY
 *
 * This is important for copying text from:
 *
 * - normal HTML elements
 * - paragraphs
 * - headings
 * - spans
 * - inputs
 * - textareas
 */
window.addEventListener(
  "copy",
  (event) => {
    console.log("Allowing copy");

    event.stopImmediatePropagation();
  },
  true,
);

/*
 * 3. CUT
 */
window.addEventListener(
  "cut",
  (event) => {
    console.log("Allowing cut");

    event.stopImmediatePropagation();
  },
  true,
);

/*
 * 4. PASTE
 *
 * Allows the browser's normal paste operation.
 *
 * We intentionally DON'T call preventDefault().
 */
window.addEventListener(
  "paste",
  (event) => {
    console.log("Allowing paste");

    event.stopImmediatePropagation();
  },
  true,
);

/*
 * 5. BEFOREINPUT
 *
 * The website you showed specifically blocks:
 *
 * insertFromPaste
 * insertFromDrop
 * insertReplacementText
 *
 * So intercept only those cases.
 *
 * Normal typing is NOT touched.
 */
window.addEventListener(
  "beforeinput",
  (event) => {
    if (isPasteInput(event)) {
      console.log("Allowing beforeinput:", event.inputType);

      event.stopImmediatePropagation();
    }
  },
  true,
);

/*
 * 6. TEXT SELECTION
 *
 * Allows selecting text on the page.
 */
window.addEventListener(
  "selectstart",
  (event) => {
    console.log("Allowing text selection");

    event.stopImmediatePropagation();
  },
  true,
);

/*
 * 7. CONTEXT MENU
 *
 * Allows right-click.
 */
window.addEventListener(
  "contextmenu",
  (event) => {
    console.log("Allowing context menu");

    event.stopImmediatePropagation();
  },
  true,
);

/*
 * 8. DRAG START
 *
 * Allows normal text dragging.
 */
window.addEventListener(
  "dragstart",
  (event) => {
    console.log("Allowing dragstart");

    event.stopImmediatePropagation();
  },
  true,
);

/*
 * 9. DROP
 *
 * Allows normal drop behaviour.
 */
window.addEventListener(
  "drop",
  (event) => {
    console.log("Allowing drop");

    event.stopImmediatePropagation();
  },
  true,
);

/*
 * 10. KEYUP
 *
 * Kuch websites keyup par bhi clipboard shortcuts
 * ko rokti hain, isliye isse bhi allow karte hain.
 */
window.addEventListener(
  "keyup",
  (event) => {
    if (isClipboardShortcut(event)) {
      console.log("Allowing clipboard keyup:", event.key);

      event.stopImmediatePropagation();
    }
  },
  true,
);
